Gentoo Plymouth theme
====================

Install:
  sudo cp -r gentoo-plymouth /usr/share/plymouth/themes/
  sudo plymouth-set-default-theme gentoo-plymouth

Rebuild your initramfs using your distribution tool (e.g. dracut --force or genkernel initramfs).

The boot and shutdown logo frames were replaced with the Gentoo logo. The original progress bar and password UI are preserved.
